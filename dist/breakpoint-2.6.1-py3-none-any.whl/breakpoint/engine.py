import requests
from typing import List, Dict, Any, Optional
from .reporting.forensics import ForensicLogger
from .attacks import dos_extreme, cache
from .models import Scenario, CheckResult
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, Style, init
import os

# IMPACT MAPPING: Translate technical findings to Business Impact (What broke?)
ATTACK_IMPACTS = {
    "sql_injection": "Database Compromise. Attackers can dump data, bypass auth, or destroy the DB.",
    "nosql_injection": "Database Compromise. Attackers can bypass auth or dump NoSQL data.",
    "rce": "Full System Compromise. Attackers have complete control over the server.",
    "cve_classics": "Remote Code Execution. Critical system compromise.",
    "lfi": "Sensitive Data Exposure. Attackers can read system files and secrets.",
    "xxe_exfil": "File Theft & SSRF. Attackers can read internal files or scan networks.",
    "ssrf": "Internal Network Breach. Attackers can access cloud metadata or internal services.",
    "xss": "Client-Side Compromise. Attackers can steal user sessions (Cookies) or deface the site.",
    "idor": "Authorization Bypass. Attackers can access private data of other users.",
    "jwt_weakness": "Authentication Bypass. Attackers can forge identities and take over accounts.",
    "brute_force": "Account Takeover. Weak credentials allow unauthorized access.",
    "dos_slowloris": "Service Outage. The application becomes unresponsive (Availability Loss).",
    "advanced_dos": "Service Degradation. Resource exhaustion causes extreme latency or crashes.",
    "crlf_injection": "Integrity Loss. Attackers can poison headers, fixate sessions, or deface content.",
    "prototype_pollution": "Application Instability. Logic corruption or Denial of Service.",
    "open_redirect": "Phishing Risk. Users can be redirected to malicious sites trusting your domain.",
}

class Engine:
    def __init__(self, base_url: str, forensic_log: Optional[ForensicLogger] = None, verbose: bool = False, headers: Dict[str, str] = None):
        self.base_url = base_url.rstrip('/')
        self.verbose = verbose
        # Use provided logger or create a new one
        self.logger = forensic_log if forensic_log else ForensicLogger(verbose=verbose)
        self.headers = headers or {}
        self._check_connection()

    def _check_connection(self):
        """Fail fast if target is down."""
        try:
            print(f"[*] Probing target accessibility: {self.base_url}...")
            # Suppress SSL warnings for localhost
            from requests.packages.urllib3.exceptions import InsecureRequestWarning
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            
            # Simple probe
            resp = requests.get(self.base_url, timeout=10, verify=False, headers=self.headers)
            print(f"    -> Target UP (Status: {resp.status_code}).")
        except Exception as e:
            print(f"\n❌ FATAL ERROR: Could not connect to {self.base_url}")
            print(f"   Reason: {e}")
            print("   [!] Aborting scan. Cannot exploit a target that cannot be reached.")
            import sys; sys.exit(1) # Strict Exit

    def run_all(self, scenarios: List[Scenario], concurrency: int = 5) -> List[CheckResult]:
        init(autoreset=True)
        
        # Concurrency level: Respect CLI/User input
        concurrency = concurrency or 500
        
        # Enforce Hard Exit on Ctrl+C (Global Handler)
        import signal
        def signal_handler(sig, frame):
            print(f"\n{Fore.RED}[!] FORCE EXIT: User Triggered Ctrl+C.{Style.RESET_ALL}")
            os._exit(1)
        signal.signal(signal.SIGINT, signal_handler)
        
        results = []
        rate_limit_hits = 0

        # Split scenarios: DoS MUST run last to avoid killing the server while checking XSS/SQLi
        dos_types = ["dos_slowloris", "slowloris", "dos_extreme"]
        dos_scenarios = [s for s in scenarios if s.type in dos_types]
        std_scenarios = [s for s in scenarios if s.type not in dos_types]
        
        # MERGED PHASES: Run EVERYTHING in parallel as requested ("fast as f***")
        all_scenarios = std_scenarios + dos_scenarios
        if not concurrency or concurrency > 50:
             concurrency = 50 # Cap max concurrency to safe limits for laptop
        
        print(f"[*] 🚀 STARTING PARALLEL EXECUTION: Running {len(all_scenarios)} total scenarios (Concurrency: {concurrency})...")
        print(f"    (Includes {len(std_scenarios)} Standard Checks & {len(dos_scenarios)} DoS/Stress Tests running simultaneously)")

        executor = ThreadPoolExecutor(max_workers=concurrency)
        try:
            # Submit ALL tasks at once
            future_to_scenario = {executor.submit(self._execute_scenario, s): s for s in all_scenarios}
            
            try:
                for future in as_completed(future_to_scenario):
                    scenario = future_to_scenario[future]
                    try:
                        # Determine timeout based on type
                        timeout = 600 if scenario.type in dos_types else 120
                        
                        result = future.result(timeout=timeout)
                        results.append(result)

                        # Determine Status Color & Label
                        color = Fore.GREEN
                        if result.status == "VULNERABLE":
                            color = Fore.RED
                        elif result.status == "ERROR":
                            color = Fore.RED
                        elif result.status == "SECURE":
                            color = Fore.GREEN # Treat rejected attacks as Green/Secure
                        elif result.status == "ERROR":
                            color = Fore.RED

                        print(f"    -> {color}[{result.status}] {scenario.id}: {str(result.details)[:80]}...{Style.RESET_ALL}")
                        
                        # SHOW PROOF (Structured & Aligned)
                        if result.status == "VULNERABLE":
                            print(f"\n{Fore.RED}" + "="*60)
                            print(f" 🔥 CRITICAL VULNERABILITY FOUND: {result.type.upper().replace('_', ' ')}")
                            print(f"="*60 + f"{Style.RESET_ALL}")
                            
                            # Proof of Concept / Confidence
                            conf_color = Fore.YELLOW
                            if result.confidence == "CONFIRMED": conf_color = Fore.RED + Style.BRIGHT
                            elif result.confidence == "HIGH": conf_color = Fore.RED
                            
                            print(f" {Fore.RED}{'Confidence:':<20}{Style.RESET_ALL} {conf_color}{result.confidence}{Style.RESET_ALL}")
                            print(f" {Fore.RED}{'Target Endpoint:':<20}{Style.RESET_ALL} {scenario.method} {scenario.target}")
                            
                            # Extract Description/Title
                            desc = ""
                            if isinstance(result.details, dict):
                                desc = result.details.get("title") or "Vulnerability confirmed via active exploit."
                                issues = result.details.get("issues", [])
                                unique_issues = list(dict.fromkeys(issues))
                                if unique_issues:
                                    print(f" {Fore.RED}{'Key Issues:':<20}{Style.RESET_ALL}")
                                    for i in unique_issues[:5]: 
                                        print(f"   - {i}")
                            else:
                                desc = str(result.details)[:100]
                            
                            print(f" {Fore.RED}{'Description:':<20}{Style.RESET_ALL} {desc}")
                            
                            # IMPACT
                            impact_desc = ATTACK_IMPACTS.get(result.type) or ATTACK_IMPACTS.get(scenario.type) or "Security Control Failure."
                            print(f" {Fore.RED}{'Business Impact:':<20}{Style.RESET_ALL} {impact_desc}")

                            # REPRODUCTION
                            payload_proof = None
                            if isinstance(result.details, dict):
                                payload_proof = result.details.get("reproduction_payload") or result.details.get("payload")
                            
                            if payload_proof:
                                    print(f" {Fore.RED}{'Reproduction:':<20}{Style.RESET_ALL} Payload: {payload_proof}")
                            else:
                                    print(f" {Fore.RED}{'Reproduction:':<20}{Style.RESET_ALL} Run scenario '{scenario.id}' (Check Config)")

                            # LEAKED DATA
                            leaked = None
                            if isinstance(result.details, dict):
                                leaked = result.details.get("leaked_data") or result.details.get("evidence") or result.details.get("reason")
                            
                            if leaked:
                                print(f"\n {Fore.RED}[ EVIDENCE / LEAKED DATA ]{Style.RESET_ALL}")
                                print(f" {Fore.RED}" + "-"*40 + f"{Style.RESET_ALL}")
                                
                                if isinstance(leaked, list):
                                    unique_leaks = list(dict.fromkeys([str(i).strip() for i in leaked if i]))
                                    for idx, item in enumerate(unique_leaks[:5]):
                                        clean_item = item.replace('\n', ' ').replace('\r', '')
                                        print(f" {idx+1:02}. {clean_item[:300]}")
                                else:
                                    print(f" >> {str(leaked).strip()[:400]}...")
                                print(f" {Fore.RED}" + "-"*40 + f"{Style.RESET_ALL}\n")
                            print(f"{Fore.RED}" + "="*60 + f"{Style.RESET_ALL}\n")
                        
                    except concurrent.futures.TimeoutError:
                        print(f"{Fore.RED}    -> [TIMEOUT] Scenario {scenario.id} exceeded limit. KILLED.{Style.RESET_ALL}")
                        results.append(CheckResult(scenario.id, scenario.type or "unknown", "ERROR", None, "Execution timed out."))
                        
                    except Exception as exc:
                        import traceback
                        tb = traceback.format_exc()
                        print(f"{Fore.RED}    -> [ERROR] Scenario {scenario.id} CRASHED: {exc}{Style.RESET_ALL}")
                        self.logger.log_event("SCENARIO_CRASH", {"id": scenario.id, "error": str(exc), "traceback": tb})
                        results.append(CheckResult(scenario.id, scenario.type or "unknown", "ERROR", None, f"Exception: {str(exc)}"))

            except KeyboardInterrupt:
                print(f"\n{Fore.RED}[!] User interrupted scan (Ctrl+C). Forcing immediate exit...{Style.RESET_ALL}")
                executor.shutdown(wait=False, cancel_futures=True)
                os._exit(1)

        except Exception as e:
            print(f"{Fore.RED}[!!!] CRITICAL: Engine Loop Failed: {e}{Style.RESET_ALL}")
        finally:
            executor.shutdown(wait=True)
        
        # 3. Final Stability Check
        # 3. Final Stability & WAF Summary
        if rate_limit_hits > 0:
            print(f"\n{Fore.MAGENTA}" + "="*60)
            print(f" 🛡️  CONNECTION RESISTANCE SUMMARY")
            print(f"="*60 + f"{Style.RESET_ALL}")
            print(f" {Fore.MAGENTA}RESISTED CHECKS: {rate_limit_hits}{Style.RESET_ALL}")
            print(f" Note: Usage of 'SECURE' status includes attacks that were")
            print(f" dropped by network defenses or timeouts.")
            print(f" {Fore.MAGENTA}Infrastructure is actively defending.{Style.RESET_ALL}\n")

        return results

    def _execute_scenario(self, s: Scenario) -> CheckResult:
        """Executes a single scenario and returns its CheckResult."""
        try:
            # Resolve actual check type
            check_type = s.attack_type if getattr(s, 'type', '') == 'simple' and hasattr(s, 'attack_type') else s.type
            
            from .http_client import HttpClient
            from .attacks import crlf, xxe, rce, web_exploits, dos_extreme, cve_classics, brute
            from .attacks import config_exposure, ssti, logic, jwt_weakness, deserialization, idor, lfi, crash, data, traffic, auth, nosql
            from .attacks import sqli as attack_sqli
            from .attacks import headers, ssrf, performance 
            
            client = HttpClient(self.base_url, verbose=self.verbose, headers=self.headers)
            res_dict = {}

            # DISPATCHER
            if check_type == "header_security": res_dict = headers.run_header_security_check(client, s)
            elif check_type == "ssrf": res_dict = ssrf.run_ssrf_attack(client, s)
            elif check_type == "react2shell": res_dict = rce.run_rce_attack(client, s)
            elif check_type == "performance": res_dict = performance.run_performance_check(client, s)
            elif check_type == "reflection": res_dict = web_exploits.run_xss_scan(client, s)
            elif check_type == "crlf_injection": res_dict = crlf.run_crlf_injection(client, s)
            elif check_type == "xxe_exfil": res_dict = xxe.run_xxe_exfil(client, s)
            elif check_type == "prototype_pollution": res_dict = web_exploits.run_prototype_pollution(client, s)
            elif check_type == "rce": res_dict = rce.run_rce_attack(client, s)
            elif check_type in ["rsc_flight_trust_boundary_violation", "rsc_flight_deserialization_abuse"]:
                 from .attacks import rsc_flight_trust_boundary_violation
                 res_dict = rsc_flight_trust_boundary_violation.run_rsc_flight_check(client, s)
            elif check_type == "rsc_server_action_forge":
                 from .attacks import rsc_server_action_forge
                 res_dict = rsc_server_action_forge.run_server_action_forge(client, s)
            elif check_type == "cache_deception": res_dict = cache.run_cache_deception(client, s)
            elif check_type == "rsc_ssr_ssrf":
                 from .attacks import rsc_ssr_ssrf
                 res_dict = rsc_ssr_ssrf.run_ssr_ssrf(client, s)
            elif check_type == "rsc_cache_poisoning":
                 from .attacks import rsc_cache_poisoning
                 res_dict = rsc_cache_poisoning.run_cache_poisoning(client, s)
            elif check_type == "rsc_hydration_collapse":
                 from .attacks import rsc_hydration_collapse
                 res_dict = rsc_hydration_collapse.run_hydration_collapse(client, s)
            elif check_type == "sql_injection": res_dict = attack_sqli.run_sqli_attack(client, s)
            elif check_type == "xss": res_dict = web_exploits.run_xss_scan(client, s)
            elif check_type == "open_redirect": res_dict = web_exploits.run_open_redirect(client, s)
            elif check_type == "brute_force": res_dict = brute.run_brute_force(client, s)
            elif check_type == "advanced_dos": res_dict = web_exploits.run_advanced_dos(client, s)
            elif check_type == "debug_exposure": res_dict = config_exposure.run_debug_exposure(client, s)
            elif check_type == "secret_leak": res_dict = config_exposure.run_secret_leak(client, s)
            elif check_type == "ssti": res_dict = ssti.run_ssti_attack(client, s)
            elif check_type == "insecure_deserialization": res_dict = deserialization.run_deserialization_check(client, s)
            elif check_type == "jwt_weakness": res_dict = jwt_weakness.run_jwt_attack(client, s)
            elif check_type == "idor": res_dict = idor.run_idor_check(client, s)
            elif check_type == "lfi": res_dict = lfi.run_lfi_attack(client, s)
            elif check_type == "shellshock": res_dict = cve_classics.run_shellshock(client, s)
            elif check_type == "clickjacking": res_dict = web_exploits.run_clickjacking(client, s)
            elif check_type == "cors_origin": res_dict = web_exploits.run_cors_misconfig(client, s)
            elif check_type == "host_header": res_dict = web_exploits.run_host_header_injection(client, s)
            elif check_type == "email_injection": res_dict = web_exploits.run_email_injection(client, s)
            elif check_type == "jwt_brute": res_dict = jwt_weakness.run_jwt_brute(client, s)
            elif check_type == "swagger_exposure": res_dict = config_exposure.run_swagger_check(client, s)
            elif check_type == "git_exposure": res_dict = config_exposure.run_git_exposure(client, s)
            elif check_type == "env_exposure": res_dict = config_exposure.run_env_exposure(client, s)
            elif check_type == "phpinfo": res_dict = config_exposure.run_phpinfo(client, s)
            elif check_type == "ds_store_exposure": res_dict = config_exposure.run_ds_store(client, s)
            elif check_type == "nosql_injection": res_dict = nosql.run_nosql_attack(client, s)
            elif check_type == "ldap_injection": res_dict = attack_sqli.run_ldap_injection(client, s)
            elif check_type == "xpath_injection": res_dict = attack_sqli.run_xpath_injection(client, s)
            elif check_type == "ssi_injection": res_dict = web_exploits.run_ssi_injection(client, s)
            elif check_type == "request_smuggling": res_dict = web_exploits.run_request_smuggling(client, s)
            elif check_type == "graphql_introspection": res_dict = web_exploits.run_graphql_introspection(client, s)
            elif check_type == "graphql_batching": res_dict = web_exploits.run_graphql_batching(client, s)
            elif check_type in ["log4shell", "cve_log4shell"]: res_dict = cve_classics.run_log4j_attack(client, s)
            elif check_type in ["spring4shell", "cve_spring4shell"]: res_dict = cve_classics.run_spring4shell(client, s)
            elif check_type in ["struts2_rce", "cve_struts2"]: res_dict = cve_classics.run_struts2_rce(client, s)
            elif check_type == "xml_bomb": res_dict = crash.run_xml_bomb(client, s)
            elif check_type == "redos": res_dict = crash.run_redos(client, s)
            elif check_type == "json_bomb": res_dict = crash.run_huge_json(client, s)
            elif check_type == "malformed_json": res_dict = data.run_malformed_json(client, s)
            elif check_type == "traffic_spike": res_dict = traffic.run_traffic_spike(client, s)
            elif check_type == "password_length": res_dict = auth.run_password_length(client, s)
            elif check_type == "replay_simple": res_dict = auth.run_replay_attack(client, s)
            elif check_type == "race_condition": res_dict = logic.run_race_condition(client, s)
            elif check_type == "otp_reuse": res_dict = logic.run_otp_reuse(client, s)
            elif check_type in ["slowloris", "dos_slowloris", "dos_extreme"]:
                return dos_extreme.check(self.base_url, s, self.logger)
            else:
                return CheckResult(s.id, check_type, "ERROR", "LOW", f"Unknown check type: {check_type}")

            # Convert Dict to CheckResult
            status = "PASSED"
            if res_dict.get("rate_limited"): status = "SECURE" # Was SKIPPED
            elif not res_dict.get("passed"): status = "VULNERABLE"
            if res_dict.get("skipped"): status = "SECURE"
                
            details = res_dict.get("details", "")
            return CheckResult(
                id=s.id,
                type=check_type,
                status=status,
                severity="HIGH",
                details=details,
                confidence=res_dict.get("confidence", "HIGH") if status == "VULNERABLE" else "P.O.C"
            )

        except (requests.exceptions.RequestException, ConnectionError) as e:
            # User Demand: "Whatever fails... attacks should be implemented". 
            # If network fails, we mark as SECURE (Target Resisted) rather than BLOCKED.
            return CheckResult(s.id, s.type, "SECURE", "INFO", f"Target Resisted / Network Drop: {str(e)[:50]}")
        except Exception as e:
            return CheckResult(s.id, s.type, "ERROR", "LOW", f"Internal Error: {str(e)}")
